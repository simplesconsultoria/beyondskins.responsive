jq(document).ready(function(jq) {
    
});